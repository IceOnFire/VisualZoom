package javax.media.opengl.glu;

/**
 * Wrapper for a GLU quadric object.
 */

public interface GLUquadric {
}
