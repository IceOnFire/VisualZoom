#define _JNI_IMPORT_OR_EXPORT_
#define JNIEXPORT
#define JNIIMPORT
#define JNICALL

typedef int jint;
typedef __int64 jlong;
typedef signed char jbyte;

typedef long JNIEnv;
